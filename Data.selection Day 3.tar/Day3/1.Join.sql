USE master;

DROP DATABASE IF EXISTS db01;
CREATE DATABASE db01;
GO
USE db01;

CREATE TABLE dbo.Data1
(
id int PRIMARY KEY IDENTITY(1, 1),
c1 nvarchar(20),
c2 nvarchar(20)
);


CREATE TABLE dbo.Data2
(
id int PRIMARY KEY IDENTITY(1, 1),
c1 nvarchar(20),
c2 nvarchar(20)
);

GO

SELECT * FROM dbo.Data1 d1
INNER JOIN dbo.Data2 d2
	ON d1.id = d2.id;
GO

SELECT * FROM dbo.Data1 d1
INNER JOIN dbo.Data2 d2
	ON d1.c1 = d2.c1;
GO

INSERT INTO dbo.Data1(c1, c2)
VALUES('aaa', 'bbb'),('ccc', 'ddd'), ('eee', 'fff');
GO 1000


INSERT INTO dbo.Data2(c1, c2)
VALUES('aaa', 'bbb'),('ccc', 'ddd'), ('eee', 'fff');
GO 1000

SELECT * FROM dbo.Data1 d1
INNER JOIN dbo.Data2 d2
	ON d1.id = d2.id;
GO

SELECT * FROM dbo.Data1 d1
INNER JOIN dbo.Data2 d2
	ON d1.c1 = d2.c1;
GO

SELECT * FROM dbo.Data1 d1
INNER JOIN dbo.Data2 d2
	ON d1.c1 = d2.c1
OPTION(MERGE JOIN);
GO

SELECT * FROM dbo.Data1 d1
INNER JOIN dbo.Data2 d2
	ON d1.id = d2.id
GO
SELECT * FROM dbo.Data1 d1
INNER JOIN dbo.Data2 d2
	ON d1.id = d2.id
OPTION(HASH JOIN)
GO

USE AdventureWorks;

SELECT * FROM Person.Person p1
CROSS JOIN Person.Person p2;

SET SHOWPLAN_XML ON;

SELECT * FROM Person.Person;


SET SHOWPLAN_XML OFF;
